// CONFIG1H
#pragma config OSC = HSPLL      // Oscillator Selection bits (HS oscillator, PLL enabled (Clock Frequency = 4 x FOSC1))
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor disabled)
#pragma config IESO = OFF       // Internal/External Oscillator Switchover bit (Oscillator Switchover mode disabled)

// CONFIG2L
#pragma config PWRT = ON        // Power-up Timer Enable bit (PWRT enabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bits (Brown-out Reset disabled in hardware and software)
#pragma config BORV = 3         // Brown Out Reset Voltage bits (Minimum setting)

// CONFIG2H
#pragma config WDT = OFF        // Watchdog Timer Enable bit (WDT disabled (control is placed on the SWDTEN bit))
#pragma config WDTPS = 32768    // Watchdog Timer Postscale Select bits (1:32768)

// CONFIG3H
#pragma config CCP2MX = PORTC   // CCP2 MUX bit (CCP2 input/output is multiplexed with RC1)
#pragma config PBADEN = OFF     // PORTB A/D Enable bit (PORTB<4:0> pins are configured as digital I/O on Reset)
#pragma config LPT1OSC = OFF    // Low-Power Timer1 Oscillator Enable bit (Timer1 configured for higher power operation)
#pragma config MCLRE = ON       // MCLR Pin Enable bit (MCLR pin enabled; RE3 input pin disabled)

// CONFIG4L
#pragma config STVREN = OFF     // Stack Full/Underflow Reset Enable bit (Stack full/underflow will not cause Reset)
#pragma config LVP = OFF        // Single-Supply ICSP Enable bit (Single-Supply ICSP disabled)
#pragma config XINST = OFF      // Extended Instruction Set Enable bit (Instruction set extension and Indexed Addressing mode disabled (Legacy mode))

// CONFIG5L
#pragma config CP0 = OFF        // Code Protection bit (Block 0 (000800-003FFFh) not code-protected)
#pragma config CP1 = OFF        // Code Protection bit (Block 1 (004000-007FFFh) not code-protected)
#pragma config CP2 = OFF        // Code Protection bit (Block 2 (008000-00BFFFh) not code-protected)
#pragma config CP3 = OFF        // Code Protection bit (Block 3 (00C000-00FFFFh) not code-protected)

// CONFIG5H
#pragma config CPB = OFF        // Boot Block Code Protection bit (Boot block (000000-0007FFh) not code-protected)
#pragma config CPD = OFF        // Data EEPROM Code Protection bit (Data EEPROM not code-protected)

// CONFIG6L
#pragma config WRT0 = OFF       // Write Protection bit (Block 0 (000800-003FFFh) not write-protected)
#pragma config WRT1 = OFF       // Write Protection bit (Block 1 (004000-007FFFh) not write-protected)
#pragma config WRT2 = OFF       // Write Protection bit (Block 2 (008000-00BFFFh) not write-protected)
#pragma config WRT3 = OFF       // Write Protection bit (Block 3 (00C000-00FFFFh) not write-protected)

// CONFIG6H
#pragma config WRTC = OFF       // Configuration Register Write Protection bit (Configuration registers (300000-3000FFh) not write-protected)
#pragma config WRTB = OFF       // Boot Block Write Protection bit (Boot Block (000000-0007FFh) not write-protected)
#pragma config WRTD = OFF       // Data EEPROM Write Protection bit (Data EEPROM not write-protected)

// CONFIG7L
#pragma config EBTR0 = OFF      // Table Read Protection bit (Block 0 (000800-003FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR1 = OFF      // Table Read Protection bit (Block 1 (004000-007FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR2 = OFF      // Table Read Protection bit (Block 2 (008000-00BFFFh) not protected from table reads executed in other blocks)
#pragma config EBTR3 = OFF      // Table Read Protection bit (Block 3 (00C000-00FFFFh) not protected from table reads executed in other blocks)

// CONFIG7H
#pragma config EBTRB = OFF

#include <xc.h>

void delay(unsigned int ms)
{
    unsigned int i;
    unsigned char j;
    
 for (i =0; i< ms; i++)
 {
 
  for (j =0 ; j < 200; j++)
   {
      Nop();
      Nop();
      Nop();
      Nop();
      Nop();
   }
 }
}

void main(void) {
    
    ADCON1=0x0F;
    
    TRISA=0xC3;
    TRISB=0x3F;   
    TRISC=0x01;
    TRISD=0x00;
    TRISE=0x00;



    unsigned char wybor = 1;
    unsigned int licznik = 0;
    unsigned int gray = 0;
    unsigned int bcode = 0;
    unsigned char xor;
    unsigned int dziesiatki;
    unsigned int jednosci;
    unsigned int key = 51;
    unsigned int los = 115;
    unsigned int wartoscSnake = 7;
    unsigned int czyWDol = 1;
    unsigned int kolejka = 1;
    unsigned int dlugoscKolejki = 8;
    unsigned int pozycjaKolejki = 1;
    unsigned int sumaKolejki = 0;
    
    PORTB = wybor;
    
    //Port b przyciski, d lampki
    while(1)
    {
        PORTD=licznik;
        delay(500); //Opoznienie

        //sprawdzanie czy rb3 lub rb4 jest nacisniety
        unsigned int i = 6000;
        while(PORTBbits.RB4 && PORTBbits.RB3 && i > 0)
        {
            i--;
            
        }

        if(PORTBbits.RB3 == 0)
        {
            wybor ++;
            //w przypadku wcisniecia rb3 przechodzi na kolejny kanal
        }
        else if(PORTBbits.RB4 == 0)
        {
            wybor --; 
            //w przypadku wcisniecia rb4 przechodzi na poprzedni kanal
        }
        if(PORTBbits.RB3 == 0 || PORTBbits.RB4 == 0)
        {
            licznik=0;
            bcode=0;

        }
        
         //zmiana skrajnych warto?ci kana?u (tryby numerowane od 1 do 9 w??cznie) , gdy cofniemy od pierwszego prze??czy na ostatni kana?, danie do przodu od ostatniego  prze??czy na pierwszy
        if(wybor == 0)
            wybor=9;
        else if(wybor == 10)
            wybor=1;

        if(wybor==1)
        {
            licznik++;
            //inkrementacja warto?ci wy?wietlanej na diodach
        }
        if(wybor==2)
        {
            licznik--;
            //dekrementacja warto?ci wy?wietlanej na diodach
        }
        if(wybor==3)
        {
            //przypisanie wyj?ciu warto?ci xorowania liczby z jej przesuni?ciem o 1 w prawo (np 1001 xoruje sie z przesunieciem w prawo (0100) i daje  wynik 1101)
            licznik=gray ^ (gray >> 1);
            
            //zwi?kszenie warto?ci do xorowania
            gray++;
        }
        if(wybor==4)
        {
            //analogicznie co zadanie 3 tylko z dekrementaj? warto?ci
            licznik = gray ^ (gray >> 1);
            gray--;
        }
        if(wybor==5)
        {
            //pobranie warto?ci dziesi?tnej z liczby ( dzielenie bez reszty (np. 71/10 = 7 , 70/10=7) 
            dziesiatki=bcode/10;
            
             //pobranie warto?ci jedno?ci poprzed reszte z dzielenia przez 10
            jednosci=bcode%10;
            
            //przesuniecie o 4 bity(np.1111 po przesunieciu o 4 bity da 11110000)
            dziesiatki<<= 4;
            
            //dodanie warto?ci dziesi?tnej do warto?ci jedno?ci (np liczba 11110000 + 1001 = 11111001) Zawsze w dziesi?tce b?d? 4 zera na ko?cu bo jest przesuwana o 4 bity
            dziesiatki = dziesiatki+jednosci;
            
            // przypisanie warto?ci do wy?wietlenia na diodzie
            licznik=dziesiatki;
            
            //dodanie 1 do warto?ci zamienianej 
            bcode++;
            
            //Je?eli warto?? przekroczy 100 wtedy liczbe zmienian? ustawiamy na 0, brak mo?liwo?ci wy?wietlenia liczby >=100 (liczba potrzebnych di�d=ilo?? cyfr w liczbie * 4)
            if(bcode==100)
                bcode=0;
        }
        if(wybor==6)
        {
            //analogicznie jak zadanie 5 tylko z dekrementacj? warto?ci
            dziesiatki=bcode/10;
            jednosci=bcode%10;
            dziesiatki<<= 4;
            dziesiatki = dziesiatki+jednosci;
            licznik=dziesiatki;
            bcode--;
            if(bcode==-1)
                bcode=99;
        }
        
        if(wybor==7)
        {
            //w??yk ma warto?ci 7, 14, 28, 56, 112, 224 (warto?ci s? kolejno 2x wi?ksze)
            if (czyWDol == 0)//je?eli idzie w g�r?
                if (wartoscSnake == 7) //kiedy nie mo?e bardziej i?? do g�ry
                    czyWDol = 1; //zmiana kierunku, w kt�rym idzie
                else //kiedy mo?e i?? do g�ry
                    wartoscSnake /= 2; //zmiejeszenie warto?ci dwukrotnie
            else 
                if (wartoscSnake == 224) // nie mo?e ju? bardziej w d�?
                    czyWDol = 0; //zmiana kierunku, idzie do g�ry
                else 
                    wartoscSnake *= 2; //idzie bardziej w d�?
                
                
            licznik = wartoscSnake; //przypisanie wyj?cia warto?ci w??a 
        }
        if(wybor==8)
        {
            
            if (licznik == 255) //je?eli wszystkie diody s? zapalone resetuje warto?ci dla kolejki
                {
                    dlugoscKolejki = 8; 
                    sumaKolejki = 0;
                    kolejka = 1;
                    pozycjaKolejki = 1;
                }
            
            licznik = sumaKolejki+ kolejka;// przypisanie do wyj?cia warto?ci sumykolejki (zaj?te miejsca przez poprzednie iteracje) oraz warto?? iteracji (id?cy wagonik) 
            kolejka *= 2; //przej?cie do nast?pnej diody (kolejne potegi dw�jki 1,10,100,1000,... =>1, 2,4,8,...)
            pozycjaKolejki += 1; //dodanie warto?ci do pozycji id?cego wagonika
            
            if (pozycjaKolejki  > dlugoscKolejki) //je?eli pozycja kolejki przekroczy?a d?ugo?? kolejki
            {
                //wtedy pozycja kolejki ustawiana jest na 1
                pozycjaKolejki = 1;
                //d?ugo?? kolejnej kolejki jest mniejsza o 1, bo wagonik zaj?? miejsce
                dlugoscKolejki -= 1;
                //kolejka jest zerowana
                kolejka = 0;
                //wagonik stoi na ko?cu, kolejny nie idzie, wi?c sume kolejki mo?na przypisa?
                sumaKolejki = licznik;
            }
                       
        }
        
        if(wybor==9)
        {
            //los=115 (nasza podstawowa liczba)
            
            xor = 0; //zzerowanie xora
            for (i = 0; i <= 5; i++) //p?tla dzia?ajaca 5 razy
                if ((key & (1 << i)) != 0)
                    xor ^= ((los & (1 << i)) != 0); //xorowanie 

            los >>= 1; // przesuniecie zmiennej losowej o 1 w prwo
            los |= (xor << 5);//warto?? zmiennej xor jest przesuwana bitowo w lewo o 5 pozycji
            
            licznik = los; //przypisanie 
        }       
    }
    
    return;
}