// CONFIG1H
#pragma config OSC = HSPLL      // Oscillator Selection bits (HS oscillator, PLL enabled (Clock Frequency = 4 x FOSC1))
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor disabled)
#pragma config IESO = OFF       // Internal/External Oscillator Switchover bit (Oscillator Switchover mode disabled)

// CONFIG2L
#pragma config PWRT = ON        // Power-up Timer Enable bit (PWRT enabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bits (Brown-out Reset disabled in hardware and software)
#pragma config BORV = 3         // Brown Out Reset Voltage bits (Minimum setting)

// CONFIG2H
#pragma config WDT = OFF        // Watchdog Timer Enable bit (WDT disabled (control is placed on the SWDTEN bit))
#pragma config WDTPS = 32768    // Watchdog Timer Postscale Select bits (1:32768)

// CONFIG3H
#pragma config CCP2MX = PORTC   // CCP2 MUX bit (CCP2 input/output is multiplexed with RC1)
#pragma config PBADEN = OFF     // PORTB A/D Enable bit (PORTB<4:0> pins are configured as digital I/O on Reset)
#pragma config LPT1OSC = OFF    // Low-Power Timer1 Oscillator Enable bit (Timer1 configured for higher power operation)
#pragma config MCLRE = ON       // MCLR Pin Enable bit (MCLR pin enabled; RE3 input pin disabled)

// CONFIG4L
#pragma config STVREN = OFF     // Stack Full/Underflow Reset Enable bit (Stack full/underflow will not cause Reset)
#pragma config LVP = OFF        // Single-Supply ICSP Enable bit (Single-Supply ICSP disabled)
#pragma config XINST = OFF      // Extended Instruction Set Enable bit (Instruction set extension and Indexed Addressing mode disabled (Legacy mode))

// CONFIG5L
#pragma config CP0 = OFF        // Code Protection bit (Block 0 (000800-003FFFh) not code-protected)
#pragma config CP1 = OFF        // Code Protection bit (Block 1 (004000-007FFFh) not code-protected)
#pragma config CP2 = OFF        // Code Protection bit (Block 2 (008000-00BFFFh) not code-protected)
#pragma config CP3 = OFF        // Code Protection bit (Block 3 (00C000-00FFFFh) not code-protected)

// CONFIG5H
#pragma config CPB = OFF        // Boot Block Code Protection bit (Boot block (000000-0007FFh) not code-protected)
#pragma config CPD = OFF        // Data EEPROM Code Protection bit (Data EEPROM not code-protected)

// CONFIG6L
#pragma config WRT0 = OFF       // Write Protection bit (Block 0 (000800-003FFFh) not write-protected)
#pragma config WRT1 = OFF       // Write Protection bit (Block 1 (004000-007FFFh) not write-protected)
#pragma config WRT2 = OFF       // Write Protection bit (Block 2 (008000-00BFFFh) not write-protected)
#pragma config WRT3 = OFF       // Write Protection bit (Block 3 (00C000-00FFFFh) not write-protected)

// CONFIG6H
#pragma config WRTC = OFF       // Configuration Register Write Protection bit (Configuration registers (300000-3000FFh) not write-protected)
#pragma config WRTB = OFF       // Boot Block Write Protection bit (Boot Block (000000-0007FFh) not write-protected)
#pragma config WRTD = OFF       // Data EEPROM Write Protection bit (Data EEPROM not write-protected)

// CONFIG7L
#pragma config EBTR0 = OFF      // Table Read Protection bit (Block 0 (000800-003FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR1 = OFF      // Table Read Protection bit (Block 1 (004000-007FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR2 = OFF      // Table Read Protection bit (Block 2 (008000-00BFFFh) not protected from table reads executed in other blocks)
#pragma config EBTR3 = OFF      // Table Read Protection bit (Block 3 (00C000-00FFFFh) not protected from table reads executed in other blocks)

// CONFIG7H
#pragma config EBTRB = OFF

#include <xc.h>

void delay(unsigned int ms)
{
    unsigned int i;
    unsigned char j;
    
 for (i =0; i< ms; i++)
 {
 
  for (j =0 ; j < 200; j++)
   {
      Nop();
      Nop();
      Nop();
      Nop();
      Nop();
   }
 }
}

unsigned int adc(unsigned char kanal)
{
    switch(kanal)
    {
        case 0: ADCON0=0x01; break; //P1
        case 1: ADCON0=0x05; break; //P2
        case 2: ADCON0=0x09; break; 
    }
    
    ADCON0bits.GO=1;
    while(ADCON0bits.GO == 1);

   return ((((unsigned int)ADRESH)<<2)|(ADRESL>>6));
}

void main(void) {
    
    ADCON0=0x01;
    ADCON1=0x0B;
    ADCON2=0x01;
    
    TRISA=0xC3;
    TRISB=0x3F;   
    TRISC=0x01;
    TRISD=0x00;
    TRISE=0x00;
    
    unsigned char wybor = 1;
    unsigned int licznik = 0;
    unsigned int bcode = 0;
    unsigned int dziesiatki = 0;
    unsigned int jednosci = 0;
    unsigned int potencjometr = 0;
    
    PORTB = wybor;
    
    //Port b przyciski, d lampki
    while(1)
    {
        PORTD=licznik;
         //pobranie warto?ci z potencjometru 
        potencjometr=((unsigned int)adc(1));
        
        //odpowiedni czas czekania w zale?no?ci gdzie znajduje si? wska?nik potencjometru
        if(potencjometr<=200)
            delay(300);
        else if(potencjometr<=400)
            delay(500);
        else if(potencjometr<=600)
            delay(1000);
        else if(potencjometr<=800)
            delay(1500);
        else if(potencjometr<=1024)
            delay(2000);
        
        
        
        //sprawdzanie czy rb3 lub rb4 jest nacisniety
        unsigned int i = 6000;
        while(PORTBbits.RB4 && PORTBbits.RB3 && i > 0)
        {
            i--;
            
        }

        if(PORTBbits.RB3 == 0)
        {
            wybor ++;
            //w przypadku wcisniecia rb3 przechodzi na kolejny kanal
        }
        else if(PORTBbits.RB4 == 0)
        {
            wybor --; 
            //w przypadku wcisniecia rb4 przechodzi na poprzedni kanal
            
        }
        
        //zmiana skrajnych warto?ci kana?u (tryby numerowane 1,2) , gdy cofniemy od pierwszego prze??czy na ostatni kana?, danie do przodu od ostatniego  prze??czy na pierwszy 
        if(wybor == 0)
            wybor=2;
        else if(wybor == 3)
            wybor=1;
        
        if(wybor==1)
        {
            //inkrementacja warto?ci wy?wietlanej na diodach
            licznik++;
        }
        if(wybor==2)
        {
            //pobranie warto?ci dziesi?tnej z liczby ( dzielenie bez reszty (np. 71/10 = 7 , 70/10=7) 
            dziesiatki=bcode/10;
            
            //pobranie warto?ci jedno?ci poprzed reszte z dzielenia przez 10
            jednosci=bcode%10;
            
            dziesiatki<<= 4; //przesuniecie o 4 bity(np.1111 po przesunieciu o 4 bity da 11110000)
            
            //dodanie warto?ci dziesi?tnej do warto?ci jedno?ci (np liczba 11110000 + 1001 = 11111001) Zawsze w dziesi?tce b?d? 4 zera na ko?cu bo jest przesuwana o 4 bity
            dziesiatki = dziesiatki+jednosci;
            
            // przypisanie warto?ci do wy?wietlenia na diodzie
            licznik=dziesiatki;
            
            //dodanie 1 do warto?ci zamienianej 
            bcode++;
            
            //Je?eli warto?? przekroczy 100 wtedy liczbe zmienian? ustawiamy na 0, brak mo?liwo?ci wy?wietlenia liczby >=100 (liczba potrzebnych di�d=ilo?? cyfr w liczbie * 4)
            if(bcode==100)
                bcode=0;
            
        }
    }
    
    
    return;
}
